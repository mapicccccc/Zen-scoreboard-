package net.zenith.zenscore;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public final class ZenScoreboard extends JavaPlugin implements Listener {
    private static final String MENU_TITLE = ChatColor.DARK_BLUE + "Scoreboard Settings";
    private final Map<UUID, Map<String, Boolean>> toggles = new HashMap<>();
    private final String[] keys = {"name", "rank", "money", "kills", "deaths", "shards", "ping"};
    private final String[] labels = {"Player Name", "Rank", "Money", "Kills", "Deaths", "Shards", "Ping"};
    private final Material[] materials = {Material.NAME_TAG, Material.NETHER_STAR, Material.GOLD_INGOT, Material.IRON_SWORD, Material.SKELETON_SKULL, Material.AMETHYST_SHARD, Material.CLOCK};

    @Override public void onEnable() {
        saveDefaultConfig();
        if (getCommand("scoreboard") != null) getCommand("scoreboard").setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
            openMenu(p); return true;
        });
        if (getCommand("zenscoreboard") != null) getCommand("zenscoreboard").setExecutor((sender, command, label, args) -> {
            if (!sender.hasPermission("zenscoreboard.admin")) { sender.sendMessage(color("&cNo permission.")); return true; }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) { reloadConfig(); sender.sendMessage(color("&aZenScoreboard reloaded.")); }
            else sender.sendMessage(color("&eUse /zenscoreboard reload")); return true;
        });
        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) { loadToggles(p); createScoreboard(p); }
        long period = Math.max(10, getConfig().getLong("scoreboard.update-ticks", 20));
        Bukkit.getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::updateScoreboard), period, period);
    }

    @Override public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) saveToggles(p);
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { loadToggles(e.getPlayer()); Bukkit.getScheduler().runTaskLater(this, () -> createScoreboard(e.getPlayer()), 2L); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { saveToggles(e.getPlayer()); toggles.remove(e.getPlayer().getUniqueId()); }

    private void loadToggles(Player p) {
        Map<String, Boolean> map = new HashMap<>();
        for (String key : keys) map.put(key, getConfig().getBoolean("players." + p.getUniqueId() + "." + key, getConfig().getBoolean("defaults." + key, true)));
        toggles.put(p.getUniqueId(), map);
    }
    private void saveToggles(Player p) {
        Map<String, Boolean> map = toggles.get(p.getUniqueId()); if (map == null) return;
        for (String key : keys) getConfig().set("players." + p.getUniqueId() + "." + key, map.getOrDefault(key, true));
        saveConfig();
    }
    private boolean enabled(Player p, String key) { return toggles.computeIfAbsent(p.getUniqueId(), id -> new HashMap<>()).getOrDefault(key, true); }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, MENU_TITLE);
        for (int i = 0; i < keys.length; i++) {
            ItemStack item = new ItemStack(enabled(p, keys[i]) ? materials[i] : Material.GRAY_DYE);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(color((enabled(p, keys[i]) ? "&a✔ &f" : "&c✘ &7") + labels[i]));
            meta.setLore(List.of(color("&7Click to " + (enabled(p, keys[i]) ? "&cdisable" : "&aenable") + "&7 this line.")));
            item.setItemMeta(meta); inv.setItem(10 + i, item);
        }
        ItemStack info = new ItemStack(Material.BOOK); ItemMeta im = info.getItemMeta(); im.setDisplayName(color("&bYour scoreboard settings")); im.setLore(List.of(color("&7Only changes your own scoreboard."), color("&7Settings save when you leave."))); info.setItemMeta(im); inv.setItem(22, info);
        p.openInventory(inv);
    }

    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        if (!MENU_TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true); if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getRawSlot() - 10; if (slot < 0 || slot >= keys.length) return;
        String key = keys[slot]; toggles.computeIfAbsent(p.getUniqueId(), id -> new HashMap<>()).put(key, !enabled(p, key));
        openMenu(p); updateScoreboard(p);
    }

    private void createScoreboard(Player p) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("zensb", "dummy", color(getConfig().getString("scoreboard.title", "&b&lDONUTSMP")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR); p.setScoreboard(board); updateScoreboard(p);
    }
    private void updateScoreboard(Player p) {
        Scoreboard board = p.getScoreboard(); Objective obj = board.getObjective("zensb");
        if (obj == null) { createScoreboard(p); return; }
        obj.setDisplayName(color(getConfig().getString("scoreboard.title", "&b&lDONUTSMP")));
        for (String entry : new ArrayList<>(board.getEntries())) board.resetScores(entry);
        List<String> lines = new ArrayList<>();
        List<String> configured = getConfig().getStringList("scoreboard.lines");
        for (String raw : configured) {
            String lower = ChatColor.stripColor(color(raw)).toLowerCase(Locale.ROOT);
            String key = null;
            if (lower.contains("%player_name%") || lower.contains("name:")) key = "name";
            else if (lower.contains("%luckperms_prefix%") || lower.contains("rank:")) key = "rank";
            else if (lower.contains("%vault_eco_balance") || lower.contains("money:")) key = "money";
            else if (lower.contains("%statistic_player_kills%") || lower.contains("kills:")) key = "kills";
            else if (lower.contains("%statistic_deaths%") || lower.contains("deaths:")) key = "deaths";
            else if (lower.contains("%shards_balance%") || lower.contains("shards:")) key = "shards";
            else if (lower.contains("%player_ping%") || lower.contains("ping:")) key = "ping";
            if (key != null && !enabled(p, key)) continue;
            String line = raw.replace("%player_name%", p.getName()).replace("%statistic_player_kills%", String.valueOf(p.getStatistic(Statistic.PLAYER_KILLS))).replace("%statistic_deaths%", String.valueOf(p.getStatistic(Statistic.DEATHS))).replace("%player_ping%", String.valueOf(p.getPing()));
            if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) line = PlaceholderAPI.setPlaceholders(p, line);
            lines.add(color(line));
        }
        if (lines.size() > 15) lines = lines.subList(0, 15);
        Set<String> unique = new HashSet<>(); int score = lines.size();
        for (String line : lines) {
            String entry = line; while (!unique.add(entry)) entry = line + ChatColor.values()[unique.size() % ChatColor.values().length];
            String teamName = "z" + score; Team team = board.getTeam(teamName); if (team == null) team = board.registerNewTeam(teamName);
            String prefix = entry.length() > 64 ? entry.substring(0, 64) : entry; team.addEntry(entry); team.setPrefix(prefix);
            obj.getScore(entry).setScore(score--);
        }
    }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
}
